"""Decides how serious an event is for *you*: per-location profiles, world rules,
quiet hours. Pure functions: easy to test and tune."""
from __future__ import annotations

import html
from datetime import datetime, time as dtime, timedelta, timezone

from .config import Config
from .models import Event, haversine_km, level_rank, max_level

EMOJI = {"critical": "🔴 CRITICAL", "high": "🟠 HIGH", "info": "🔵 INFO"}


def _quake_level(rules: dict, mag: float, dist: float) -> str:
    for lvl in ("critical", "high", "info"):
        for min_mag, max_km in rules.get(lvl, []):
            if mag >= min_mag and dist <= max_km:
                return lvl
    return "none"


def evaluate(ev: Event, cfg: Config, now: datetime | None = None) -> tuple[str, str]:
    """Return (level, reason)."""
    now = now or datetime.now(timezone.utc)
    if not ev.ongoing and ev.time < now - timedelta(hours=cfg.get("max_event_age_hours", 6)):
        return "none", "too old"

    best, reason = "none", ""

    def consider(level: str, why: str):
        nonlocal best, reason
        if level_rank(level) > level_rank(best):
            best, reason = level, why

    # Location-bound items (warnings, forecasts)
    if ev.fixed_levels:
        for loc_id, lvl in ev.fixed_levels.items():
            loc = cfg.location(loc_id)
            consider(lvl, f"for {loc.name if loc else loc_id}")
        return best, reason

    dists = []
    if ev.lat is not None and ev.lon is not None:
        dists = sorted(((haversine_km(ev.lat, ev.lon, l.lat, l.lon), l) for l in cfg.locations), key=lambda x: x[0])

    world = cfg.get("world", {})
    if ev.kind == "quake" and ev.magnitude is not None:
        for d, loc in dists:
            consider(_quake_level(cfg.profile(loc.profile)["quake"], ev.magnitude, d), f"{d:.0f} km from {loc.name}")
        wq = world.get("quake", {})
        if ev.magnitude >= wq.get("high", 99):
            consider("high", "major earthquake (world)")
        elif ev.magnitude >= wq.get("info", 99):
            consider("info", "strong earthquake (world)")

    elif ev.kind == "gdacs":
        alert, etype = ev.details.get("alertlevel"), ev.details.get("eventtype")
        local_map = {"green": "info", "orange": "high", "red": "critical"}
        for d, loc in dists:
            if d <= cfg.profile(loc.profile).get("gdacs_radius_km", 0):
                lvl = local_map.get(alert, "none")
                if etype == "EQ" and alert != "red":
                    lvl = "none"           # local quakes are handled by the seismic feeds
                consider(lvl, f"{d:.0f} km from {loc.name}")
        wg = world.get("gdacs", {})
        if alert in ("red", "orange"):
            lvl = wg.get(alert, "none")
            if etype == "DR":
                lvl = "info" if alert == "red" else "none"
            if etype == "EQ" and alert == "orange":
                lvl = "none"
            consider(lvl, f"GDACS {alert} alert (world)")

    elif ev.kind == "tsunami":
        if ev.details.get("threat"):
            pacific_watch = any(d <= 3000 or (ev.details.get("mentions_chile") and loc.country == "CL")
                                for d, loc in dists) or ev.details.get("mentions_chile")
            if pacific_watch:
                chile = [l.name for l in cfg.locations if l.country == "CL"]
                consider("critical", "tsunami threat possibly affecting " + (", ".join(chile) or "your locations"))
            else:
                consider("high", "tsunami threat (world)")

    return best, reason


def in_quiet_hours(cfg: Config, now: datetime | None = None) -> bool:
    now = (now or datetime.now(timezone.utc)).astimezone(cfg.tz)
    q = cfg.get("quiet_hours") or {}
    if not q.get("start") or not q.get("end"):
        return False
    s = dtime.fromisoformat(q["start"])
    e = dtime.fromisoformat(q["end"])
    t = now.time()
    return (s <= t or t < e) if s > e else (s <= t < e)


def _fmt_time(ev: Event, cfg: Config, reason: str) -> str:
    mine = ev.time.astimezone(cfg.tz)
    s = f"{mine:%a %d %b %H:%M} your time"
    # also show local time if the event is closest to a location in another timezone
    for loc in cfg.locations:
        if loc.name in reason and loc.tz != cfg.get("timezone"):
            s += f" ({ev.time.astimezone(loc.zone):%H:%M} in {loc.name})"
            break
    return s


def format_alert(ev: Event, level: str, reason: str, cfg: Config, event_id: int, update: bool = False) -> str:
    e = html.escape
    head = EMOJI.get(level, level.upper())
    if update:
        head += " · UPDATE"
    lines = [f"<b>{head}</b>", f"<b>{e(ev.title)}</b>"]
    if reason:
        lines.append(e(reason[0].upper() + reason[1:]))
    if ev.kind == "quake":
        depth = ev.details.get("depth_km")
        lines.append(f"{_fmt_time(ev, cfg, reason)}" + (f" · depth {depth:.0f} km" if depth is not None else ""))
    elif ev.kind == "warning":
        exp = ev.details.get("expires")
        exp_s = datetime.fromisoformat(exp).astimezone(cfg.tz).strftime("%a %d %H:%M") if exp else "?"
        lines.append(f"From {ev.time.astimezone(cfg.tz):%a %d %H:%M} to {exp_s} (your time)")
    elif ev.kind == "gdacs":
        sev = ev.details.get("severity")
        if sev:
            lines.append(e(sev))
    elif ev.kind == "tsunami":
        if ev.details.get("bulletin"):
            lines.append(e(ev.details["bulletin"]))
    if ev.sources:
        lines.append("Sources: " + e(", ".join(ev.sources)))
    if ev.url:
        lines.append(f'<a href="{e(ev.url, quote=True)}">Details</a>')
    lines.append(f"#E{event_id}")
    return "\n".join(lines)


def digest_line(ev: Event, level: str, reason: str, cfg: Config, event_id: int) -> str:
    e = html.escape
    icon = {"critical": "🔴", "high": "🟠", "info": "🔵"}.get(level, "•")
    when = ev.time.astimezone(cfg.tz).strftime("%d %b %H:%M")
    return f"{icon} {e(ev.title)} — {e(reason)} ({when}) #E{event_id}"
